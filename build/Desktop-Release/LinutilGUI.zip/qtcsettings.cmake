# This file is managed by Qt Creator, do not edit!

set("CMAKE_BUILD_TYPE" "Release" CACHE "STRING" "" FORCE)
set("CMAKE_COLOR_DIAGNOSTICS" "ON" CACHE "BOOL" "" FORCE)
set("CMAKE_CXX_COMPILER" "/usr/bin/g++" CACHE "FILEPATH" "" FORCE)
set("CMAKE_C_COMPILER" "/usr/bin/gcc" CACHE "FILEPATH" "" FORCE)
set("CMAKE_GENERATOR" "Unix Makefiles" CACHE "STRING" "" FORCE)
set("CMAKE_PREFIX_PATH" "/usr" CACHE "PATH" "" FORCE)
set("CMAKE_PROJECT_INCLUDE_BEFORE" "/mnt/Sten/Stuff/LinutilGUI/LinutilGUI/build/Desktop-Release/.qtcreator/cmake-helper/qtcreator-project.cmake" CACHE "FILEPATH" "" FORCE)
set("QT_CREATOR_ENABLE_MAINTENANCE_TOOL_PROVIDER" "ON" CACHE "BOOL" "" FORCE)
set("QT_CREATOR_ENABLE_PACKAGE_MANAGER_SETUP" "ON" CACHE "BOOL" "" FORCE)
set("QT_ENABLE_QML_DEBUG" "OFF" CACHE "BOOL" "" FORCE)
set("QT_QMAKE_EXECUTABLE" "/usr/bin/qmake6" CACHE "FILEPATH" "" FORCE)